package com.example.project136.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.project136.Adapters.CategoryAdapter;
import com.example.project136.Adapters.PupolarAdapter;
import com.example.project136.Domains.CategoryDomain;
import com.example.project136.Domains.PopularDomain;
import com.example.project136.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView.Adapter adapterPopular, adapterCat;
    private RecyclerView recyclerViewPopular, recyclerViewCategory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initRecyclerView();
    }

    private void initRecyclerView() {
        ArrayList<PopularDomain> items = new ArrayList<>();
        items.add(new PopularDomain("Danau Baikal", "Siberia selatan, Rusia", "Lake Baikal, a natural wonder hidden in the heart of Siberia, Russia, is an invaluable gem that captivates visitors with its extraordinary beauty and exceptional uniqueness. Known as the deepest and oldest lake in the world, Lake Baikal is not just a tourist destination but also a stunning natural marvel.\n" +
                "\n" +
                "With its incredibly clear water, Lake Baikal serves as a window into an underwater world full of wonders. Beautiful coral reefs and rare aquatic fauna can be easily observed, creating an unforgettable diving experience. Above the surface, the vast Siberian plains and towering mountains provide a majestic backdrop.\n" +
                "\n" +
                "Winter at Lake Baikal adds its own charm by freezing the water and creating a stunning layer of transparent ice. During this time, visitors can enjoy activities such as driving on the ice, ice fishing, or even strolling along the mesmerizing \"crystal trails.\"\n" +
                "\n" +
                "Picturesque fishing villages and traditional wooden houses contribute to the distinctive charm of Siberia, creating an atmosphere rich in history and culture. The lake's existence also protects a number of endemic species, including the famous Baikal Seal, adding a touch of uniqueness and sustainability to the Lake Baikal ecosystem.\n" +
                "\n" +
                "If you're seeking an extraordinary natural adventure, the natural wonder of Lake Baikal, with its lush green summer beauty or the enchanting frozen landscapes of winter, will provide an unforgettable travel experience, leaving your heart captivated by Russia's breathtaking natural wealth. ", 2, true, 4.8, "foto1", true, 1000));
        items.add(new PopularDomain("Green Bowl Beach", "Bali, Indonesia", "Green Bowl Beach, a hidden paradise on the southern coast of Bali, captivates visitors with its breathtaking natural beauty. Nestled among steep cliffs and lush greenery, this beach offers a unique combination of soft white sand, turquoise-blue seawater, and enchanting tranquility.\n" +
                "\n" +
                "The name \"Green Bowl\" derives from the captivating color of the sea, creating a tropical ambiance that is truly mesmerizing. To reach this beach, visitors must descend a carved staircase along the steep cliffs, adding an extra adventure before arriving at this paradise. Along the descent, you are accompanied by refreshing green forest views and the invigorating scent of the sea.\n" +
                "\n" +
                "Upon reaching Green Bowl Beach, you are welcomed by calm seawater and gentle waves, creating the perfect atmosphere for swimming or relaxing on the shore. The beach is also surrounded by small caves that can be explored, providing an additional exploration experience for visitors who want to delve into the wonders of nature.\n" +
                "\n" +
                "The beach remains relatively secluded, offering an opportunity to enjoy tranquility and natural beauty without the disturbance of crowds. With its natural and serene charm, Green Bowl Beach is an ideal escape from everyday life, allowing visitors to find peace amidst the stunning landscapes of Bali. ", 1, false, 5, "foto2", false, 2500));
        items.add(new PopularDomain("Menara Eiffel", "Paris, France", "The Eiffel Tower, a symbol of grandeur and architectural beauty, stands in the heart of Paris, France, captivating visitors with its iconic charm. Built by Gustave Eiffel in 1889 for the World's Fair, the tower has since become an undisputed major attraction, offering an unforgettable tourist experience.\n" +
                "\n" +
                "Soaring to a height of 324 meters, the Eiffel Tower provides a spectacular panoramic view from its summit. As night falls, the glittering lights adorning its structure add an unforgettable romantic touch, making the nighttime visit just as magical as during the day.\n" +
                "\n" +
                "The journey to the top of the tower involves taking an elevator or climbing stairs, and at each level, visitors are treated to increasingly breathtaking views. From the Seine River panorama to the spread of beauty that is Paris beneath, the Eiffel Tower is an ideal vantage point to admire the splendor of the City of Love.\n" +
                "\n" +
                "Beyond the scenic beauty, the height of the Eiffel Tower is complemented by an unparalleled touch of romance. Can you imagine a romantic dinner in an exclusive restaurant at the top of the tower, with Paris sparkling below under the starlit night sky? This is one of the luxurious experiences offered by the Eiffel Tower.\n" +
                "\n" +
                "With a rich history and its central position, the Eiffel Tower is not just a magnificent metal structure but an icon celebrating the beauty and timelessness of Paris. If you visit France, witnessing the height and grandeur of the Eiffel Tower is a must, bringing the charm and romance of the City of Love to life. ", 3, true, 4.3, "foto3", true, 30000));

        recyclerViewPopular = findViewById(R.id.view_pop);
        recyclerViewPopular.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        adapterPopular = new PupolarAdapter(items);
        recyclerViewPopular.setAdapter(adapterPopular);

        recyclerViewCategory = findViewById(R.id.view_cat);
        recyclerViewCategory.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        recyclerViewCategory.setAdapter(adapterCat);


    }
}